# Pneumonia-Analyzer

![image](https://github.com/MainakRepositor/Pneumonia-Detector/assets/64016811/868cc8c6-2e2c-433c-8bb3-32d23880772d)

![image](https://github.com/MainakRepositor/Pneumonia-Detector/assets/64016811/0d92fc0e-9d22-4c53-9a90-a2eb4c97d916)
